var lnuit = require('./lnuit')

// Add the style to the head
var relativePath = './css/style.css'

// call the two functions needed for this exercise
lnuit.addStyleFile(relativePath)
lnuit.addClassToAllLinks('lnu')