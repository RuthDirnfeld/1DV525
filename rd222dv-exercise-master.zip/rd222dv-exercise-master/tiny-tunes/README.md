## Tiny Tunes

Get started by watchning this recording:

* [Hello World [SWE]](https://youtu.be/-BWcNBsHMzc)

|  |  |
| ------------- | ------------- |
|  repo | [exercise-tiny-tunes](https://github.com/CS-LNU-Learning-Objects/exercise-tiny-tunes) |
| Level  | A  |
| Lectures|  [Browser](https://github.com/CS-LNU-Learning-Objects/client-side-javascript/tree/master/lectures/01-browser), [DOM & Event](https://github.com/CS-LNU-Learning-Objects/client-side-javascript/tree/master/lectures/02-domevent) |
| Keywords| Getting started, DOM, Events, Templates, Document Fragment|
| Solutions | [Code](https://github.com/CS-LNU-Learning-Objects/exercise-tiny-tunes/tree/solution)<br>[Recording](https://youtu.be/Ng0-sJGG9wE)|