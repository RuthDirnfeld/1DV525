'use strict'
/*
var exercise01 = require('./ex01')
exercise01.solve()

var exercise02 = require('./ex02')
exercise02.solve()

var exercise03 = require('./ex03')
exercise03.solve()

var exercise04 = require('./ex04')
exercise04.solve()

var exercise05 = require('./ex05')
exercise05.solve()

var exercise06 = require('./ex06')
exercise06.solve()

var exercise07 = require('./ex07')
exercise07.solve()

var exercise08 = require('./ex08')
exercise08.solve()
*/
var exercise09 = require('./ex09')
exercise09.solve()