function exercise05 () {
    var element = document.querySelector('#step05 .greybox')
    element.addEventListener('click', function listener () {
      var pElement = document.createElement('p')
      pElement.appendChild(document.createTextNode('You clicked!'))
      document.querySelector('#step05').appendChild(pElement)
      this.removeEventListener('mousedown', listener)
    })
  }

  module.exports.solve = exercise05()