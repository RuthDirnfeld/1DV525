function exercise04 () {
    var headline = document.querySelector('#step04 h2')
    headline.classList.add('red')
  }

  module.exports.solve = exercise04