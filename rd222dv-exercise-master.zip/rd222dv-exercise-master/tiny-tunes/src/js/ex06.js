function exercise06 () {
    var frag = document.createDocumentFragment()
  
      // Create numerous list items, add to fragment
    var i
    for (i = 0; i < 10; i += 1) {
      var li = document.createElement('li')
      li.innerHTML = 'List item ' + (i + 1)
      frag.appendChild(li)
    }
  
    document.querySelector('#list06').appendChild(frag)
  }

  module.exports.solve = exercise06()