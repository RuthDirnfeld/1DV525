function exercise09 () {
    var textBoxes = document.querySelectorAll('#step09 input')
    var username = textBoxes[0]
    var confirmUsername = textBoxes[1]
    var message = document.querySelector('#step09 p.validation')
  
    document.querySelector('#textboxes09').addEventListener('blur', function () {
      var uText = username.value
      var cText = confirmUsername.value
  
      if (uText.length > 0 && cText.length > 0) {
        if (uText === cText) {
          message.innerHTML = 'Username OK'
        } else {
          message.innerHTML = 'Username and confirm username is not the same'
        }
      } else {
        message.innerHTML = ''
      }
    }, true)
  }

  module.exports.solve = exercise09()