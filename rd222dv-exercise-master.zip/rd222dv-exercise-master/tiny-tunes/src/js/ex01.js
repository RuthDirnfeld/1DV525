function exercise01 () {
    var tag = document.querySelector('#step01_hello')
    var textNode = document.createTextNode('Hello World!')
    tag.appendChild(textNode)
  }
  module.exports.solve = exercise01