function exercise02 () {
    var step02 = document.querySelector('#step02')
    var textNode = document.createTextNode('This is a sub headline')
    var headline = document.createElement('h3')
    headline.appendChild(textNode)
    step02.appendChild(headline)
  }

  module.exports.solve = exercise02