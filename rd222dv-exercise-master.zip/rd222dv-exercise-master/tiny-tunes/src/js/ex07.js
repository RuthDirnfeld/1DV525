function exercise07 () {
    var liTemplate
    var templateNode = document.querySelector('#step07-template')
    var i
    for (i = 0; i < 5; i += 1) {
      liTemplate = document.importNode(templateNode.content, true)
      liTemplate.firstElementChild.querySelector('a').innerHTML = 'Min länk'
      liTemplate.querySelector('a').setAttribute('href', 'http://sunet.se')
      document.querySelector('#list07').appendChild(liTemplate)
    }
  }

  module.exports.solve = exercise07()