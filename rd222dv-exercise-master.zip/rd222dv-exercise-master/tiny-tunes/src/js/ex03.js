function exercise03(){
    var headlines = document.querySelectorAll('h2')
    var textNode = document.createTextNode('Blaah')
    var headline = document.createElement('h3')
    headline.appendChild(textNode)
    
    var parent = headlines[3].parentElement
    parent.insertBefore(headline, parent.lastElementChild)
}

module.exports.solve = exercise03