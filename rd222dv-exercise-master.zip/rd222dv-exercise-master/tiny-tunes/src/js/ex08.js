function exercise08 () {
    var button = document.querySelector('#todolistform button')
    button.addEventListener('click', function clickListener () {
      var textValue = document.querySelector('#todolistform input').value
  
      if (textValue.length > 0) {
        var li = document.createElement('li')
        var textNode = document.createTextNode(textValue)
        li.appendChild(textNode)
        var ul = document.querySelector('#todolist ul')
        ul.appendChild(li)
      }
    })
  }

  module.exports.solve = exercise08()