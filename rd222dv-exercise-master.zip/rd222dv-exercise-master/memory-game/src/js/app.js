var memory = require('./Memory')

memory.playMemory(2, 2, 'memoryContainer')
