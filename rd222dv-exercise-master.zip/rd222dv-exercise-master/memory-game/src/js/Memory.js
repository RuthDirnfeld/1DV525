// module.exports is the interface
module.exports = {
  // playMemory public function
  // that will return the playmemory inner function
  playMemory: playMemory,
  shuffle: getPictureArray
}

function playMemory (rows, cols, container) {
  // a was img before
  var a
  var tiles = []
  var turn1
  var turn2
  var lastTile
  var pairs = 0
  var tries = 0 // track number of tries, how many time the second brick is clicked
  tiles = getPictureArray(rows, cols)
  container = document.getElementById(container)
  // importing the template from index file, 0 because we only have one
  var templateDiv = document.querySelectorAll('#memoryContainer template')[0].content.firstElementChild

  // separate each memory game from each other, false because we don't want a copy of textnode and a tag
  var div = document.importNode(templateDiv, false)

  // iterates tiles from 0 to 15, tile - gives the value of the picture,
  // index - we get the index of the tile in the array
  tiles.forEach(function (tile, index) {
    // gives us the image, imports image from the template
    a = document.importNode(templateDiv.firstElementChild, true)
    // since we have the index, we can look what the tile number is in the tiles array
    a.firstElementChild.setAttribute('data-bricknumber', index)
    //
    div.appendChild(a)
    // (i+1) because picture starts at 0, but we want img1 and so on
    if ((index + 1) % cols === 0) {
      div.appendChild(document.createElement('br'))
    }
  })
  // go for click event on buttons and forms, not on images - images are not interacting by default,
  // so don't make them, by using javascript
  // one event listener and when clicked, it will present which img was clicked
  div.addEventListener('click', function (event) {
    //
    event.preventDefault()
    // big letters when it comes to element names
    // 'IMG' ? element : element.firstElementChild ---> if the nodename is IMG, we got image,
    // otherwise we get the first child of the a type which is the image
    var img = event.target.nodeName === 'IMG' ? event.target : event.target.firstElementChild
    // if we have a lot of bricks - this will work in practice, because other way would be slow
    var index = parseInt(img.getAttribute('data-bricknumber'))
    turnBrick(tiles[index], index, img)
  })
  //
  // we add the div to the container after we have populated the div
  container.appendChild(div)
  // how to turn the brick? change the source of the image, tile and index
  // have nor eference to the image
  function turnBrick (tile, index, img) {
    if (turn2) { return }
    //
    img.src = 'image/' + tile + '.png'
    // first brick is clicked
    if (!turn1) {
      turn1 = img
      lastTile = tile
      return
      // second brick is clicked
    } else {
      // img is a reference to the DOM image - we should
      // not be able to click the same image twice
      if (img === turn1) { return }
      //
      tries += 1
      //
      turn2 = img
      if (tile === lastTile) {
        // Found a pair
        pairs += 1
        // if we have found all pairs - win conditionS
        if (pairs === (cols * rows) / 2) {
          console.log('Win on ' + tries + ' number of tries')
        }
        window.setTimeout(function () {
          turn1.parentNode.classList.add('removed')
          turn2.parentNode.classList.add('removed')
          turn1 = null
          turn2 = null
        }, 300)
        //
      } else {
        // if not pair, turn them back around -hide
        // timeout needed, so that picture turns aroudn slowly
        window.setTimeout(function () {
          turn1.src = 'image/0.png'
          turn2.src = 'image/0.png'
          //
          turn1 = null
          turn2 = null
          //
        }, 500)
      }
    }
  }
}
// shuffle function
function getPictureArray (rows, cols) {
  var arr = []
  var i
  // we will put each img twice in the array - so divide by 2
  for (i = 1; i <= (rows * cols) / 2; i += 1) {
    arr.push(i)
    arr.push(i)
  }
  // [1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8]

  // shuffle function
  for (var i = arr.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1))
    var temp = arr[i]
    arr[i] = arr[j]
    arr[j] = temp
  }
  // debugger
  return arr
}
