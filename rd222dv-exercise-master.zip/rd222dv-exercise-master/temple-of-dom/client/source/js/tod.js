var elementNumber = 0
var attributeNumber = 0
var commentNumber = 0
var textNodeNumber = 0

/**
 * Check the node if it is an attribute or Element and update counter
 * @param node
 */
function updateElementOrAttribute (node) {
  if (node.tagName) {
    elementNumber += 1
  }

  if (node.attributes && node.attributes.length > 0) {
    attributeNumber += node.attributes.length
  }
}

/**
 * recursive function that examinates each node and updates the counters
 * @param {Element} node
 */
function nodeCount (node) {
  switch (node.nodeType) {
    case 1: updateElementOrAttribute(node); break
    case 3: textNodeNumber += 1; break
    case 8: commentNumber += 1; break
    default: break
  }

  if (!node.childNodes) {
    return
  }

  for (var i = 0; i < node.childNodes.length; i += 1) {
    nodeCount(node.childNodes[i])
  }
}

/**
 * Print result in the provided template
 * @param {String} templateID - the ID of the template in the HTML
 */
function UseTemplate (templateID) {
  var arr = []
  arr.push({ headline: 'Number of elements', value: elementNumber })
  arr.push({ headline: 'Number of attributes', value: attributeNumber })
  arr.push({ headline: 'Number of comments', value: commentNumber })
  arr.push({ headline: 'Number of text nodes', value: textNodeNumber })

  var template = document.getElementById(templateID)
  for (var i = 0; i < arr.length; i += 1) {
    var clone = document.importNode(template.content, true)
    clone.querySelector('h3').textContent = arr[i].headline
    clone.querySelector('p').textContent = arr[i].value
    document.querySelector('body').appendChild(clone)
  }
}

/**
 * Start the app by running calls to function
 * @param {String} templateID - The id to the template where stuff is presented
 * @param {Node} node to examinate - optional
 */
function run (templateID, node) {
  node = node || document.children[0]
  nodeCount(node)
  UseTemplate(templateID)

  // resets after each run
  elementNumber = 0
  attributeNumber = 0
  commentNumber = 0
  textNodeNumber = 0
}

/**
 * Public API - Expose the run method
 * @type {{run: run}}
 */
module.exports = {
  run: run
}
