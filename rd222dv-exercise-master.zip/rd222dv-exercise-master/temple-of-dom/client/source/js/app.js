var nodeCounter = require('./tod')
nodeCounter.run('resultTemplate')
